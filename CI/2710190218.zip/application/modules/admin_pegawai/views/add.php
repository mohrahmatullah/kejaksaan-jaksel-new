<!-- <form class="" id="submitpegawaiAdd" method="post" action="" enctype="multipart/form-data">
	<div class="form-group" id="newpegawai">
		<div>
			<label class="control-label col-lg-12"><h4>Tambah Pegawai</h4></label>
			<div class="clearfix"></div>
			<hr style="margin: 0px 15px 20px 15px;">
			<div class="clearfix"></div>

			<label class="control-label col-lg-2">NIK</label>
			<div class="col-lg-6" style="padding-bottom: 10px;">
				<input type="text" id="nik" name="nik" class="form-control" value="">
			</div>
			<div class="clearfix"></div>
			<label class="control-label col-lg-2">Nama</label>
			<div class="col-lg-6" style="padding-bottom: 10px;">
				<input type="hidden" id="idpegawai" name="idpegawai" class="form-control" value="" >
				<input type="text" id="namapegawai" name="namapegawai" class="form-control" value="" required>
			</div>
			<label class="control-label col-lg-1">Jabatan</label>
			<div class="col-lg-3" style="padding-bottom: 10px;">
				<select id="jabatanpegawai" class="form-control select2" name="jabatanpegawai" style="width:100%;" required>
						<option value="">Pilih Jabatan</option>
						<?php
								foreach ($pegawaitype as $data){
						?>
								<option value="<?=$data["id_jabatan"]?>"><?=$data["nama"]?></option>
						<?php
								}
						?>
				</select>
			</div>
			<div class="clearfix"></div>
			<label class="control-label col-lg-2">Alamat</label>
			<div class="col-lg-10" style="padding-bottom: 10px;">
				<input type="text" id="alamatpegawai" name="alamatpegawai" class="form-control" value="">
			</div>
			<div class="clearfix"></div>
			<label class="control-label col-lg-2">Propinsi</label>
			<div class="col-lg-4" style="padding-bottom: 10px;">
				<select id="proppegawai" class="form-control select2" name="proppegawai" style="width:100%;">
						<option value="">Pilih Propinsi</option>
						<?php
								foreach ($propinsiall as $data){
						?>
								<option value="<?=$data["id_propinsi"]?>"><?=$data["nama_propinsi"]?></option>
						<?php
								}
						?>
				</select>
			</div>
			<label class="control-label col-lg-2">Kota/Kabupaten</label>
			<div class="col-lg-4" style="padding-bottom: 10px;" id="divKab">
				<select id="kabpegawai" class="form-control select2" name="kabpegawai" style="width:100%;">
						<option value="">Pilih Propinsi Dahulu</option>
				</select>
			</div>
			<div class="clearfix"></div>
			<label class="control-label col-lg-2">No. Telp</label>
			<div class="col-lg-4" style="padding-bottom: 10px;">
				<input type="text" id="telppegawai" name="telppegawai" class="form-control" value="">
			</div>
			<label class="control-label col-lg-2">Email</label>
			<div class="col-lg-4" style="padding-bottom: 10px;">
				<input type="text" id="emailpegawai" name="emailpegawai" class="form-control" value="">
			</div>

			<div class="clearfix"></div>
			<hr style="margin: 10px 15px 20px 15px;">
			<div class="clearfix"></div>

			<div class="col-lg-2"></div>
			<div class="col-lg-4">
				<button type="submit" class="btn btn-info btn-block" name="submit">Simpan Data Pegawai</button>
			</div>
			<div class="col-lg-2">
				<a href="javascript:void(0);" onclick="back();" class="btn btn-warning btn-block">Kembali Ke Tabel</a>
			</div>
			<div class="col-lg-4"></div>
		</div>

	</div>
</form>
<div class="clearfix"></div> -->

<main>
    <section class="px-5">
      <section class="px-3 mt-3 mb-4">
        <div style="font-size: 2em;font-weight: 500;">Tambah Pegawai &nbsp;<a href=""><img class="" src="<?= ASSETS_IMAGE ?>/ico_ref.png" style="width: 50px;height: auto;" /></a></div>
      </section>
      
      <section class="px-3 mb-4">
        <div class="row">
          <div class="col-12">
            <form class="row" id="submitpegawaiAdd" method="post" action="" enctype="multipart/form-data">

              <div class="col-12 col-lg-9 mb-4" id="newpegawai">
                <div class="row mb-2">
                  <div class="col-6">
                    <div class="row">
                      <div class="col-12">
                        <h4>Nik</h4>
                        <div class="form-sprint-bg">
                          <input type="text" id="nik" name="nik" value="" class="form-sprint" placeholder="" />
                        </div>
                        
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-12">
                        <h4>Nama</h4>
                        <div class="form-sprint-bg">
                        	<input type="hidden" id="idpegawai" name="idpegawai" class="form-control" value="" >
							<input type="text" id="namapegawai" name="namapegawai" class="form-sprint" value="" required>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-12">
                        <h4>Alamat</h4>
                        <div class="form-sprint-bg">
                        	<input type="text" id="alamatpegawai" name="alamatpegawai" class="form-sprint" value="">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-12">
                        <h4>Provinsi</h4>
                        <div class="form-sprint-bg">
                        	<select id="proppegawai" class="form-sprint select2" name="proppegawai" style="width:100%;">
									<option value="">Pilih Propinsi</option>
									<?php
											foreach ($propinsiall as $data){
									?>
											<option value="<?=$data["id_propinsi"]?>"><?=$data["nama_propinsi"]?></option>
									<?php
											}
									?>
							</select>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-12">
                        <h4>Kota / Kabupaten</h4>
                        <div class="form-sprint-bg" id="divKab">
							<select id="kabpegawai" class="form-sprint select2" name="kabpegawai" style="width:100%;">
									<option value="">Pilih Propinsi Dahulu</option>
							</select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-6">
                  	<div class="row">
                      <div class="col-12">
                        <h4>No. Telp</h4>
                        <div class="form-sprint-bg">
                          <input type="text" id="telppegawai" name="telppegawai" class="form-sprint" value="">
                        </div>
                        
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-12">
                        <h4>Jabatan</h4>
                        <div class="form-sprint-bg">
							<select id="jabatanpegawai" class="form-sprint select2" name="jabatanpegawai" style="width:100%;" required>
									<option value="">Pilih Jabatan</option>
									<?php
											foreach ($pegawaitype as $data){
									?>
											<option value="<?=$data["id_jabatan"]?>"><?=$data["nama"]?></option>
									<?php
											}
									?>
							</select>
                        </div>
                      </div>
                    </div>                    
                    <div class="row">
                      <div class="col-12">
                        <h4>Email</h4>
                        <div class="form-sprint-bg">
                        	<input type="text" id="emailpegawai" name="emailpegawai" class="form-sprint" value="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12 col-lg-3 mb-4 d-flex align-items-lg-end">
                <button style="background: linear-gradient(to right, rgb(254,193,0) , rgb(247,228,0));border: none;padding: 7px 23px;font-size: 10pt;font-weight: normal;border-radius: 18px;" type="submit" name="submit">Simpan Data Pegawai</button>
              </div>

            </form>
          </div>
        </div>
      </section>
    </section>
</main>

<script>
	function back(){
		var urlAdd = "<?php echo base_url().'admin_pegawai/lists_pegawai'; ?>";
		$.ajax({
			url:urlAdd,
			beforeSend: function() {
				NProgress.start();
			},
			success:function(data) { 
				NProgress.done();
				$("#ajax_page").html(data);
				$(".select2").select2();
			}
		});
		//return false;
	}
	
	$(document).ready(function() {	
	
			$('#proppegawai').change(function() {
					var urlHideUnhide = "<?php echo base_url().'admin_pegawai/get_opsi_kabupaten/'; ?>" + $('#proppegawai').val();
					$.ajax({
						url:urlHideUnhide,
						beforeSend: function() {
							NProgress.start();
						},
						success:function(data) { 
							NProgress.done();
							$("#divKab").html(data);
							$(".select2").select2();
						}
					});
					return false;
			});
			
			$('#submitpegawaiAdd').submit(function(event) {
				event.preventDefault();
				var idpegawai = $("#idpegawai").val();
				var nik = $("#nik").val();
				var nama = $("#namapegawai").val();
				var jabatan = $("#jabatanpegawai").val();
				var alamat = $("#alamatpegawai").val();
				var propinsi = $("#proppegawai").val();
				var kabupaten = $("#kabpegawai").val();
				var telp = $("#telppegawai").val();
				var email = $("#emailpegawai").val();
				
				var formData = {
						'idpegawai' : idpegawai,
						'nik' : nik,
						'nama' : nama,
						'jabatan' : jabatan,
						'alamat' : alamat,
						'propinsi' : propinsi,
						'kabupaten' : kabupaten,
						'telp' : telp,
						'email' : email
				};

				var urlSearch = "<?= base_url('admin_pegawai/simpan_pegawai') ?>";

				$.ajax({
					type:'POST',
					url:urlSearch,
					data:formData,
					beforeSend: function() {
						NProgress.start();
					},
					success:function(data) { 
						NProgress.done();
						$("#ajax_page").html(data);
						$(".select2").select2();
					}
				});
				//return false;
			});
			
	});
</script>				
