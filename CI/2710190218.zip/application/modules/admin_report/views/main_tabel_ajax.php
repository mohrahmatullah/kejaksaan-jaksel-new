<!-- <div class="col-lg-8">
	<form class="" id="submitcarireport" method="post" action="" enctype="multipart/form-data">
			<label class="control-label col-lg-1 col-xs-10 col-sm-10" style="margin-top:8px;padding:0;">Cari</label>
			<div class="col-lg-5" style="padding:0;">
					<input type="text" id="caricust" name="caricust" class="form-control" value="">
			</div>
			<div class="col-lg-1 col-xs-1 col-sm-1" style="padding:0;">
				<button class="btn btn-info" id="caribtn" onclick="caricust();" type="submit"><i class="fa fa-search"></i></button>
			</div>
			<div class="col-lg-1 col-xs-1 col-sm-1" style="padding:0;">
				<a class="btn btn-warning" id="carireset" href="javascript:void(0);" onclick="carireset();" type="button" title="reset"><i class="fa fa-refresh"></i></a>
			</div>
			<div class="col-lg-4"></div>
	</form>
</div>


<div class="col-lg-4">
	<button class="btn btn-primary" style="float:right;margin-right:20px;" onclick="getPDF('.pdf-download')"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Export Report to PDF</button>
</div>


<div class="clearfix"></div>
<hr style="margin: 10px 15px 10px 15px;">
<div class="clearfix"></div>
						
<? if ($this->session->flashdata('pesan') != ''){ ?>
<div class="form-group row" style="padding: 0 20px 0 15px;">
	<label class="alert alert-success col-lg-12"><?= $this->session->flashdata('pesan') ?></label>
</div>
<? } ?>											

<div class="table-responsive pdf-download">
    <table  class="posttable display table table-bordered table-striped" id="dynamic-table">
    <thead>
    <tr>
        <th style="width: 20px;">No</th>
        <th>Tanggal</th>
        <th>Nama Pegawai</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $total = $count;
    foreach ($rec as $data){
							?>  
    <tr>
        <td><?= $no; ?></td>
        <td><?= date('d-m-Y', strtotime($data['tglbuat'])) ?></td>
        <td><?= $data['namapegawai'] ?></td>
    </tr>
    <?php
    $no++;
    }
    ?>               
    </tbody>
    </table>
</div>
												
<?= $paginator ?>
		
<script>
	function carireset(){
		var urlAdd = "<?php echo base_url().'admin_report/lists_report/0/1'; ?>";
		$.ajax({
			url:urlAdd,
			beforeSend: function() {
				NProgress.start();
			},
			success:function(data) { 
				NProgress.done();
				$("#ajax_page").html(data);
				$(".select2").select2();
			}
		});
		return false;
	}
	
	$(document).ready(function() {	
	
			$('#submitcarireport').submit(function(event) {
				event.preventDefault();
				var cari = $("#caricust").val();
				
				var formData = {
						'cari' : cari
				};

				var urlSearch = "<?= base_url('admin_report/lists_report') ?>" ;

				$.ajax({
					type:'POST',
					url:urlSearch,
					data:formData,
					beforeSend: function() {
						NProgress.start();
					},
					success:function(data) { 
						NProgress.done();
						$("#ajax_page").html(data);
						$(".select2").select2();
					}
				});
				//return false;
			});
			
	});
</script>
<script src="<?= ASSETS_JS ?>kendo.all.min.js"></script>
<script type="text/javascript">
  function getPDF(selector) {
      kendo.drawing.drawDOM($(selector)).then(function (group) {
        kendo.drawing.pdf.saveAs(group, "Report-sprint-kejaksaan-negeri.pdf");
      });
    }
</script> -->

          <section class="px-3 mb-4">
            <div class="" style="width: 700px;">
              <div class="row">
                <div class="col-12">
                  <span style="font-size: 24pt;">Cari</span>
                  <div style="position: relative;display: inline-block;width: 80%;">
                    <input class="px-3" style="font-size: 16pt;width: 100%;height: 60px;border-radius: 50px;border-color: rgba(0,0,0,.60);border-width: 1px;"/>
                    <a href="" class="position-absolute" style="top: 0;right: 0;"><img class="" src="<?= ASSETS_IMAGE ?>/ico_src.png" style="width: 40px;height: auto;margin: .5rem 1rem;" /></a>
                  </div>
                  &nbsp;<a href=""><img class="" src="<?= ASSETS_IMAGE ?>/ico_add.png" style="width: 50px;height: auto;" /></a>
                </div>
              </div>
            </div>
            
          </section>
          <section class="px-3 mb-4">
            <div class="" style="width: 700px;">
              <div class="row">
                <div class="col-12">
                    <button class="btn btn-primary" style="float:right;margin-right:20px;" onclick="getPDF('.pdf-download')"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Export Report to PDF</button>
                </div>
              </div>
            </div>
          </section>
          
          <section class="px-3 mb-4">
            <div class="row">
              <div class="col-12">
                <div class="row">
                  <?php
				    $total = $count;
				    foreach ($rec as $data){
				  ?>
                  <div class="col-12 col-lg-4 mb-4">
                    <div class="list-c">
                      <span class="list-c-dt"><?= date('d-m-Y', strtotime($data['tglbuat'])) ?></span>
                      <a href="" class="list-c-nm"><?= $data['namapegawai'] ?></a>
                      <button type="button" data-toggle="modal" data-target=".bd-example-modal-xl" class="list-c-mn"><img class="" src="<?= ASSETS_IMAGE ?>/m_ico.png" style="width: 40px;height: auto;" /></button>
                    </div>
                  </div>
                  	<?php
				    	$no++;
				    }
				    ?>

                </div>
              </div>
            </div>
          </section>

          <div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
              <div class="modal-content custom p-3">
                <div class="row mx-0 mb-3" style="border-bottom: 1px solid rgb(0,0,0);">
                  <div class="col-12 d-flex justify-content-between align-items-center pb-2">
                    <h5 class="d-inline-flex">1 Januari 2019</h5>
                    <div class="d-inline-flex" style="background: red;border-radius: 20px;padding: 5px 15px;color: rgb(255,255,255);font-size: 12pt;font-weight: normal;">Belum Terverifikasi</div>
                  </div>
                </div>
                <div class="row mx-0 mb-3">
                  <div class="col-12">
                    <h5 class="mb-3"><strong>Nama Pegawai</strong></h5>
                    <h5 class="mb-1">PER-006/A/JA/07/2017</h5>
                    <h5 class="mb-1">SOP Pengawalan Tahan Pidum</h5>
                    <h5 class="mb-3">Sprint kajari B- /0.1.14/01/2019</h5>
                    <h5 class="mb-1">File Before : <a href="">filename.jpg</a></h5>
                    <h5 class="mb-1">File After : <a href="">filename.jpg</a></h5>
                    <h5 class="mb-3">Deskripsi.........</h5>
                  </div>
                  <div class="col-12 text-right">
                    <a href=""><img class="" src="<?= ASSETS_IMAGE ?>/ico_add.png" style="width: 50px;height: auto;" /></a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <script>
          function carireset(){
            var urlAdd = "<?php echo base_url().'admin_report/lists_report/0/1'; ?>";
            $.ajax({
              url:urlAdd,
              beforeSend: function() {
                NProgress.start();
              },
              success:function(data) { 
                NProgress.done();
                $("#ajax_page").html(data);
                $(".select2").select2();
              }
            });
            return false;
          }
          
          $(document).ready(function() {  
          
              $('#submitcarireport').submit(function(event) {
                event.preventDefault();
                var cari = $("#caricust").val();
                
                var formData = {
                    'cari' : cari
                };

                var urlSearch = "<?= base_url('admin_report/lists_report') ?>" ;

                $.ajax({
                  type:'POST',
                  url:urlSearch,
                  data:formData,
                  beforeSend: function() {
                    NProgress.start();
                  },
                  success:function(data) { 
                    NProgress.done();
                    $("#ajax_page").html(data);
                    $(".select2").select2();
                  }
                });
                //return false;
              });
              
          });
        </script>
        <script src="<?= ASSETS_JS ?>kendo.all.min.js"></script>
        <script type="text/javascript">
          function getPDF(selector) {
              kendo.drawing.drawDOM($(selector)).then(function (group) {
                kendo.drawing.pdf.saveAs(group, "Report-sprint-kejaksaan-negeri.pdf");
              });
            }
        </script>