
        <!-- Page content -->
        <!-- <div id="content" class="col-md-12"> -->
          
          <!-- breadcrumbs -->
          <!-- <div class="breadcrumbs">
            <ol class="breadcrumb">
              <li><a href="<?= base_url() ?>"><i class="fa fa-money"></i> Dashboard</a></li>
              <li class="active">Verifikasi Sprint Kejaksaan Negeri</li>
						</ol>
          </div> -->
          <!-- /breadcrumbs -->

          <!-- content main container -->
          <!-- <div class="main"> -->

            <!-- row -->
            <!-- <div class="row"> -->

              <!-- col 12 -->
              <!-- <div class="col-md-12"> -->
              
                <!-- tile -->
                <!-- <section class="tile cornered" style="min-height:650px;"> -->

                  <!-- tile body -->
                  <!-- <div class="tile-body"> -->
										
										<!-- <div id="ajax_page">
											<?= $this->load->view('main_tabel_ajax') ?>
										</div> -->
										
                  <!-- </div> -->
                  <!-- /tile body -->
                
                <!-- </section> -->
                <!-- /tile -->

              <!-- </div> -->
              <!-- /col 12 -->
        
            <!-- </div> -->
            <!-- /row -->

          <!-- </div> -->
          <!-- /content container -->

        <!-- </div> -->
        <!-- Page content end -->

				<!-- <script>
				function ajaxPage(urlLink)
				{  
					$.ajax({
						url:urlLink,
						beforeSend: function() {
							NProgress.start();
						},
						success:function(data) { 
							NProgress.done();
							$("#ajax_page").html(data);
							$(".select2").select2();
						}
					});
					return false;
				}				
        </script> -->
        
      <!-- Main Content -->
      <main class="main">
        <section class="px-5">
          <section class="px-3 mt-3 mb-4">
            <div style="font-size: 2em;font-weight: 500;">VERIFIKASI SPRINT KEJAKSAAN NEGERI &nbsp;<a href=""><img class="" src="<?= ASSETS_IMAGE ?>/ico_ref.png" style="width: 50px;height: auto;" /></a></div>
          </section>
          <section class="px-3 mb-4">
            <div class="" style="width: 700px;">
              <div class="row">
                <div class="col-12">
                  <span style="font-size: 24pt;">Cari</span>
                  <div style="position: relative;display: inline-block;width: 80%;">
                    <input class="px-3" style="font-size: 16pt;width: 100%;height: 60px;border-radius: 50px;border-color: rgba(0,0,0,.60);border-width: 1px;"/>
                    <a href="" class="position-absolute" style="top: 0;right: 0;"><img class="" src="<?= ASSETS_IMAGE ?>/ico_src.png" style="width: 40px;height: auto;margin: .5rem 1rem;" /></a>
                  </div>
                  &nbsp;<a href=""><img class="" src="<?= ASSETS_IMAGE ?>/ico_add.png" style="width: 50px;height: auto;" /></a>
                </div>
              </div>
            </div>
            
          </section>
          <section class="px-3 mb-4">
            <div class="row">
              <div class="col-12">
                <div class="row">
                  
                  <div class="col-12 col-lg-4 mb-4">
                    <div class="list-c">
                      <span class="list-c-dt">11/01/19</span>
                      <a href="" class="list-c-nm">Filename.jpg</a>
                      <button type="button" data-toggle="modal" data-target=".bd-example-modal-xl" class="list-c-mn"><img class="" src="<?= ASSETS_IMAGE ?>/m_ico.png" style="width: 40px;height: auto;" /></button>
                      <img class="on-ico" src="<?= ASSETS_IMAGE ?>/off_ico.png"  />
                    </div>
                  </div>

                  <div class="col-12 col-lg-4 mb-4">
                    <div class="list-c">
                      <span class="list-c-dt">11/01/19</span>
                      <a href="" class="list-c-nm">Filename.jpg</a>
                      <button type="button" data-toggle="modal" data-target=".bd-example-modal-xl" class="list-c-mn"><img class="" src="<?= ASSETS_IMAGE ?>/m_ico.png" style="width: 40px;height: auto;" /></button>
                      <img class="on-ico" src="<?= ASSETS_IMAGE ?>/on_img.png"  />
                    </div>
                  </div>

                  <div class="col-12 col-lg-4 mb-4">
                    <div class="list-c">
                      <span class="list-c-dt">11/01/19</span>
                      <a href="" class="list-c-nm">Filename.jpg</a>
                      <button type="button" data-toggle="modal" data-target=".bd-example-modal-xl" class="list-c-mn"><img class="" src="<?= ASSETS_IMAGE ?>/m_ico.png" style="width: 40px;height: auto;" /></button>
                      <img class="on-ico" src="<?= ASSETS_IMAGE ?>/off_ico.png"  />
                    </div>
                  </div>

                  <div class="col-12 col-lg-4 mb-4">
                    <div class="list-c">
                      <span class="list-c-dt">11/01/19</span>
                      <a href="" class="list-c-nm">Filename.jpg</a>
                      <button type="button" data-toggle="modal" data-target=".bd-example-modal-xl" class="list-c-mn"><img class="" src="<?= ASSETS_IMAGE ?>/m_ico.png" style="width: 40px;height: auto;" /></button>
                      <img class="on-ico" src="<?= ASSETS_IMAGE ?>/on_img.png"  />
                    </div>
                  </div>

                  <div class="col-12 col-lg-4 mb-4">
                    <div class="list-c">
                      <span class="list-c-dt">11/01/19</span>
                      <a href="" class="list-c-nm">Filename.jpg</a>
                      <button type="button" data-toggle="modal" data-target=".bd-example-modal-xl" class="list-c-mn"><img class="" src="<?= ASSETS_IMAGE ?>/m_ico.png" style="width: 40px;height: auto;" /></button>
                      <img class="on-ico" src="<?= ASSETS_IMAGE ?>/off_ico.png"  />
                    </div>
                  </div>

                  <div class="col-12 col-lg-4 mb-4">
                    <div class="list-c">
                      <span class="list-c-dt">11/01/19</span>
                      <a href="" class="list-c-nm">Filename.jpg</a>
                      <button type="button" data-toggle="modal" data-target=".bd-example-modal-xl" class="list-c-mn"><img class="" src="<?= ASSETS_IMAGE ?>/m_ico.png" style="width: 40px;height: auto;" /></button>
                      <img class="on-ico" src="<?= ASSETS_IMAGE ?>/on_img.png"  />
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </section>

          <div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
              <div class="modal-content custom p-3">
                <div class="row mx-0 mb-3" style="border-bottom: 1px solid rgb(0,0,0);">
                  <div class="col-12 d-flex justify-content-between align-items-center pb-2">
                    <h5 class="d-inline-flex">1 Januari 2019</h5>
                    <div class="d-inline-flex" style="background: red;border-radius: 20px;padding: 5px 15px;color: rgb(255,255,255);font-size: 12pt;font-weight: normal;">Belum Terverifikasi</div>
                  </div>
                </div>
                <div class="row mx-0 mb-3">
                  <div class="col-12">
                    <h5 class="mb-3"><strong>Nama Pegawai</strong></h5>
                    <h5 class="mb-1">PER-006/A/JA/07/2017</h5>
                    <h5 class="mb-1">SOP Pengawalan Tahan Pidum</h5>
                    <h5 class="mb-3">Sprint kajari B- /0.1.14/01/2019</h5>
                    <h5 class="mb-1">File Before : <a href="">filename.jpg</a></h5>
                    <h5 class="mb-1">File After : <a href="">filename.jpg</a></h5>
                    <h5 class="mb-3">Deskripsi.........</h5>
                  </div>
                  <div class="col-12 text-right">
                    <a href=""><img class="" src="<?= ASSETS_IMAGE ?>/ico_add.png" style="width: 50px;height: auto;" /></a>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </section>
      </main>
      <!-- /Main Content -->

