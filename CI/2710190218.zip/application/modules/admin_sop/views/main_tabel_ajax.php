<!-- <div class="col-lg-8">
	<form class="" id="submitcarisop" method="post" action="" enctype="multipart/form-data">
			<label class="control-label col-lg-1" style="margin-top:8px;padding:0;">Cari</label>
			<div class="col-lg-5" style="padding:0;">
					<input type="text" id="caricust" name="caricust" class="form-control" value="">
			</div>
			<div class="col-lg-1" style="padding:0;">
				<button class="btn btn-info" id="caribtn" onclick="caricust();" type="submit"><i class="fa fa-search"></i></button>
			</div>
			<div class="col-lg-1" style="padding:0;">
				<a class="btn btn-warning" id="carireset" href="javascript:void(0);" onclick="carireset();" type="button" title="reset"><i class="fa fa-refresh"></i></a>
			</div>
			<div class="col-lg-4"></div>
	</form>
</div>
<div class="col-lg-4">
	<button class="btn btn-primary" style="float:right;margin-right:20px;" id="addsopbtn" onclick="addnew();"><i class="fa fa-plus-square"></i> Tambah sop</button>
</div>

<div class="clearfix"></div>
<hr style="margin: 10px 15px 10px 15px;">
<div class="clearfix"></div>
						
<? if ($this->session->flashdata('pesan') != ''){ ?>
<div class="form-group row" style="padding: 0 20px 0 15px;">
	<label class="alert alert-success col-lg-12"><?= $this->session->flashdata('pesan') ?></label>
</div>
<? } ?>											

<div class="table-responsive">
    <table  class="posttable display table table-bordered table-striped" id="dynamic-table">
    <thead>
    <tr>
        <th style="width: 20px;">No</th>
        <th>Nama SOP</th>
        <th>Peraturan Nomor</th>
        <th>File</th>
        <th width="12%">&nbsp;</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $total = $count;
    foreach ($rec as $data){
							?>  
    <tr>
        <td><?= $no; ?></td>
        <td><?= $data['nama'] ?></td>
        <td><?= $data['nomor'] ?></td>
        <td>
        	<? if ($data['file'] != ''){ ?>
        	<a href="<?= base_url().'uploads/sop/'.$data['file'] ?>" target="_blank"><i class="fa fa-file-o"></i></a>
        	<? } ?>
        </td>
        <td style="text-align:center;">
            <a class="btn btn-primary btn-sm" href="javascript:void(0);" onclick="editid(<?=$data["id_sop"] ?>,<?= $hal ?>,'<?= $cari ?>');" title="Edit" type="button"><i class="fa fa-pencil"></i></a>
			<? if ($this->session->userdata('user_login_level') == 'superadmin'){ ?>
				<a class="btn btn-danger btn-sm" href="javascript:void(0);" onclick="if (confirm('Apakah data akan dihapus ?')) deleteid(<?=$data["id_sop"] ?>,<?= $hal ?>,'<?= $cari ?>')" title="Delete" type="button"><i class="fa fa-trash"></i></a>
			<? } ?>
        </td>
    </tr>
    <?php
    $no++;
    }
    ?>               
    </tbody>
    </table>
</div> -->

  <section class="px-3 mb-4">
    <div class="" style="width: 700px;">
      <div class="row">
        <div class="col-12">
          <span style="font-size: 24pt;">Cari</span>
          <div style="position: relative;display: inline-block;width: 80%;">
            <input class="px-3" style="font-size: 16pt;width: 100%;height: 60px;border-radius: 50px;border-color: rgba(0,0,0,.60);border-width: 1px;"/>
            <a href="" class="position-absolute" style="top: 0;right: 0;"><img class="" src="<?= ASSETS_IMAGE ?>/ico_src.png" style="width: 40px;height: auto;margin: .5rem 1rem;" /></a>
          </div>
          &nbsp;<a href="#" id="addsopbtn" onclick="addnew();"><img class="" src="<?= ASSETS_IMAGE ?>/ico_add.png" style="width: 50px;height: auto;" /></a>
        </div>
      </div>
    </div>    
  </section>
    <? if ($this->session->flashdata('pesan') != ''){ ?>
	<div class="form-group row" style="padding: 0 20px 0 15px;">
		<label class="alert alert-success col-lg-12"><?= $this->session->flashdata('pesan') ?></label>
	</div>
	<? } ?>	
  <section class="px-3 mb-4">
    <div class="row">
      <div class="col-12">
        <div class="row">
          <?php
		    $total = $count;
		    foreach ($rec as $data){
									?>
          <div class="col-12 col-lg-4 mb-4">
            <div class="list-c">
              <span class="list-c-dt"><?= $data['nomor'] ?></span>
              <a href="javascript:void(0);" onclick="editid(<?=$data["id_sop"] ?>,<?= $hal ?>,'<?= $cari ?>');" title="Edit" type="button" class="list-c-nm"><?= $data['nama'] ?></a>
              <button type="button" data-toggle="modal" data-target=".bd-example-modal-xl" class="list-c-mn"><img class="" src="<?= ASSETS_IMAGE ?>/m_ico.png" style="width: 40px;height: auto;" /></button>
            </div>
          </div>          
		    <?php
		    $no++;
		    }
		    ?> 
        </div>
      </div>
    </div>
  </section>

  <div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content custom p-3">
        <div class="row mx-0 mb-3" style="border-bottom: 1px solid rgb(0,0,0);">
          <div class="col-12 d-flex justify-content-between align-items-center pb-2">
            <h5 class="d-inline-flex">1 Januari 2019</h5>
            <div class="d-inline-flex" style="background: red;border-radius: 20px;padding: 5px 15px;color: rgb(255,255,255);font-size: 12pt;font-weight: normal;">Belum Terverifikasi</div>
          </div>
        </div>
        <div class="row mx-0 mb-3">
          <div class="col-12">
            <h5 class="mb-3"><strong>Nama Pegawai</strong></h5>
            <h5 class="mb-1">PER-006/A/JA/07/2017</h5>
            <h5 class="mb-1">SOP Pengawalan Tahan Pidum</h5>
            <h5 class="mb-3">Sprint kajari B- /0.1.14/01/2019</h5>
            <h5 class="mb-1">File Before : <a href="">filename.jpg</a></h5>
            <h5 class="mb-1">File After : <a href="">filename.jpg</a></h5>
            <h5 class="mb-3">Deskripsi.........</h5>
          </div>
          <div class="col-12 text-right">
            <a href=""><img class="" src="<?= ASSETS_IMAGE ?>/ico_add.png" style="width: 50px;height: auto;" /></a>
          </div>
        </div>
      </div>
    </div>
  </div>
												
<?= $paginator ?>
		
<script>
	function carireset(){
		var urlAdd = "<?php echo base_url().'admin_sop/lists_sop/0/1'; ?>";
		$.ajax({
			url:urlAdd,
			beforeSend: function() {
				NProgress.start();
			},
			success:function(data) { 
				NProgress.done();
				$("#ajax_page").html(data);
				$(".select2").select2();
			}
		});
		return false;
	}
	
	function addnew(){
		var urlAdd = "<?php echo base_url().'admin_sop/add_sop'; ?>";
		$.ajax({
			url:urlAdd,
			beforeSend: function() {
				NProgress.start();
			},
			success:function(data) { 
				NProgress.done();
				$("#ajax_page").html(data);
				$(".select2").select2();
			    $('#tanggal').datepicker({
			    	format: 'dd-mm-yyyy',
			        todayHighlight: true
			    });
			    $('.btn-file :file').on('fileselect', function(event, numFiles, label) {
			        
			        var input = $(this).parents('.input-group').find(':text'),
			          log = numFiles > 1 ? numFiles + ' files selected' : label;
			        
			        if( input.length ) {
			          input.val(log);
			        } else {
			          if( log ) alert(log);
			        }
			        
			    });
			    $('#deskripsi').summernote({
			        height: 150   //set editable area's height
			    });
			}
		});
		//return false;
	}
	
	function editid(id,page,cari){
		var urlHideUnhide = "<?php echo base_url().'admin_sop/edit_sop/'; ?>" + id + "/" + page + "/" + cari;
		$.ajax({
			url:urlHideUnhide,
			beforeSend: function() {
				NProgress.start();
			},
			success:function(data) { 
				NProgress.done();
				$("#ajax_page").html(data);
				$(".select2").select2();
			    $('#tanggal').datepicker({
			    	format: 'dd-mm-yyyy',
			        todayHighlight: true
			    });
			    $('.btn-file :file').on('fileselect', function(event, numFiles, label) {
			        
			        var input = $(this).parents('.input-group').find(':text'),
			          log = numFiles > 1 ? numFiles + ' files selected' : label;
			        
			        if( input.length ) {
			          input.val(log);
			        } else {
			          if( log ) alert(log);
			        }
			        
			    });
			    $('#deskripsi').summernote({
			        height: 150   //set editable area's height
			    });
			}
		});
		return false;
	}

	function deleteid(id,page,cari){
		var urlHideUnhide = "<?php echo base_url().'admin_sop/delete/'; ?>" + id + "/" + page + "/" + cari;
		$.ajax({
			url:urlHideUnhide,
			beforeSend: function() {
				NProgress.start();
			},
			success:function(data) { 
				NProgress.done();
				$("#ajax_page").html(data);
				$(".select2").select2();
			}
		});
		return false;
	}
	
	$(document).ready(function() {	
	
			$('#submitcarisop').submit(function(event) {
				event.preventDefault();
				var cari = $("#caricust").val();
				
				var formData = {
						'cari' : cari
				};

				var urlSearch = "<?= base_url('admin_sop/lists_sop') ?>" ;

				$.ajax({
					type:'POST',
					url:urlSearch,
					data:formData,
					beforeSend: function() {
						NProgress.start();
					},
					success:function(data) { 
						NProgress.done();
						$("#ajax_page").html(data);
						$(".select2").select2();
					}
				});
				//return false;
			});
			
	});
</script>				

