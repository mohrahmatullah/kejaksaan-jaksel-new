
        <!-- Page content -->
        <!-- <div id="content" class="col-md-12"> -->
          
          <!-- breadcrumbs -->
          <!-- <div class="breadcrumbs">
            <ol class="breadcrumb">
              <li><a href="<?= base_url() ?>"><i class="fa fa-home"></i> Dashboard</a></li>
              
							<li><a href="form-elements.html">Forms</a></li>
              <li class="active">Common Elements</li>
							
						</ol>
          </div> -->
          <!-- <div class="row">
            <div class="col-xs-12">
              <h2 class="hd-t"><strong>Dashboard &nbsp;</strong> <a href=""><img src="<?= ASSETS_IMAGE ?>/ico_ref.png" style="width: 40px;height: auto;" /></a></h2>
            </div>
          </div> -->
          <!-- /breadcrumbs -->

          <!-- content main container -->
          <!-- <div class="main"> -->

            <!-- row -->
            <!-- <div class="row"> -->

              <!-- col 12 -->
              <!-- <div class="col-md-12"> -->


              
                <!-- tile -->
                <!-- <section class="tile color grey cornered"> -->

                  <!-- tile body -->
                  <!-- <div class="tile-body">
										<h3>Selamat datang di Dashboard Aplikasi Kejaksaan Negeri Jakarta Selatan</h3>
										
										<p>Pada halam ini anda dapat melakukan beberapa hal berikut ini :</p>
										<ul>
											<li>Input Verification File</li>
										</ul>
                  </div> -->
                  <!-- /tile body -->
                
                <!-- </section> -->
                <!-- /tile -->

                <!-- Profile Slider -->
                <!-- <div class="owl-carousel owl-theme profile-s">
                  <div class="item">Lorem</div>
                  <div class="item">Ipsum</div>
                  <div class="item">Dolor</div>
                </div> -->
                <!-- /Profile Slider -->

                <!-- Card -->
                <!-- <section class="card-d">
                  <div class="c-d-t">
                    <img src="<?= ASSETS_IMAGE ?>/default_img.png" />
                    <div class="">
                      <h3>Username</h3>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin venenatis lacus diam, nec imperdiet sem fermentum eu. Praesent vestibulum varius semper. Aliquam erat volutpat. Curabitur vitae malesuada nibh. Ut vitae tincidunt erat, vitae sodales orci. Pellentesque sit amet sapien vel felis rutrum iaculis. In maximus posuere ex, sed cursus nisi imperdiet a. Sed nunc nisi, elementum vel odio ac, congue sagittis tortor. Nam pellentesque, leo id interdum tincidunt, lorem velit volutpat elit, eu porta nunc arcu non nisi.</p>
                    </div>
                  </div>
                  <div class="c-d-b">
                    <a href="">More</a>
                  </div>
                </section> -->
                <!-- /Card -->

              <!-- </div> -->
              <!-- /col 12 -->
        
            <!-- </div> -->
            <!-- /row -->

          <!-- </div> -->
          <!-- /content container -->

        <!-- </div> -->
        <!-- Page content end -->


      <!-- Main Content -->
      <main class="main">
        <section class="px-5">
          <section class="px-3 mb-4 mt-3">
            <div style="font-size: 2em;font-weight: 500;">Dashboard &nbsp;<a href=""><img class="" src="<?= ASSETS_IMAGE ?>/ico_ref.png" style="width: 50px;height: auto;" /></a></div>
          </section>
          <section class="px-3 mb-4">
            <div class="" style="width: 700px;">
              <div class="db-carousel owl-carousel owl-theme">
                <div class="item"><a href=""><img class="" src="<?= ASSETS_IMAGE ?>/default_ava.png" style="width: 80px;height: 80px;border-radius: 50%;object-fit: cover;" /></a></div>
                <div class="item"><a href=""><img class="" src="<?= ASSETS_IMAGE ?>/default_ava.png" style="width: 80px;height: 80px;border-radius: 50%;object-fit: cover;" /></a></div>
                <div class="item"><a href=""><img class="" src="<?= ASSETS_IMAGE ?>/default_ava.png" style="width: 80px;height: 80px;border-radius: 50%;object-fit: cover;" /></a></div>
                <div class="item"><a href=""><img class="" src="<?= ASSETS_IMAGE ?>/default_ava.png" style="width: 80px;height: 80px;border-radius: 50%;object-fit: cover;" /></a></div>
                <div class="item"><a href=""><img class="" src="<?= ASSETS_IMAGE ?>/default_ava.png" style="width: 80px;height: 80px;border-radius: 50%;object-fit: cover;" /></a></div>
                <div class="item"><a href=""><img class="" src="<?= ASSETS_IMAGE ?>/default_ava.png" style="width: 80px;height: 80px;border-radius: 50%;object-fit: cover;" /></a></div>
                <div class="item"><a href=""><img class="" src="<?= ASSETS_IMAGE ?>/default_ava.png" style="width: 80px;height: 80px;border-radius: 50%;object-fit: cover;" /></a></div>
                <div class="item"><a href=""><img class="" src="<?= ASSETS_IMAGE ?>/default_ava.png" style="width: 80px;height: 80px;border-radius: 50%;object-fit: cover;" /></a></div>
                <div class="item"><a href=""><img class="" src="<?= ASSETS_IMAGE ?>/default_ava.png" style="width: 80px;height: 80px;border-radius: 50%;object-fit: cover;" /></a></div>
                <div class="item"><a href=""><img class="" src="<?= ASSETS_IMAGE ?>/default_ava.png" style="width: 80px;height: 80px;border-radius: 50%;object-fit: cover;" /></a></div>
                <div class="item"><a href=""><img class="" src="<?= ASSETS_IMAGE ?>/default_ava.png" style="width: 80px;height: 80px;border-radius: 50%;object-fit: cover;" /></a></div>
                <div class="item"><a href=""><img class="" src="<?= ASSETS_IMAGE ?>/default_ava.png" style="width: 80px;height: 80px;border-radius: 50%;object-fit: cover;" /></a></div>
              </div>
            </div>
            
          </section>
          <section class="px-3 mb-4">
            <div class="row">
              <div class="col-12">
                <div class="row" style="background: #e6e6e6;padding: 2rem;min-height: 40vh;border-bottom-left-radius: 135px;box-shadow: 7px 2px 6px 0px #ccc;">
                  <div class="col-3 col-xl-2">
                    <img class="of-cover w-100 h-auto" src="<?= ASSETS_IMAGE ?>/default_img.png" />
                  </div>
                  <div class="col-9 col-xl-10">
                    <h4>Username</h4>
                    <p style="font-size: 14pt;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin venenatis lacus diam, nec imperdiet sem fermentum eu. Praesent vestibulum varius semper. Aliquam erat volutpat. Curabitur vitae malesuada nibh. Ut vitae tincidunt erat, vitae sodales orci. Pellentesque sit amet sapien vel felis rutrum iaculis. In maximus posuere ex, sed cursus nisi imperdiet a. Sed nunc nisi, elementum vel odio ac, congue sagittis tortor. Nam pellentesque, leo id interdum tincidunt, lorem velit volutpat elit, eu porta nunc arcu non nisi.</p>
                    <a href="" class="text-right" style="display: inherit;font-size: 14pt;">More</a>
                  </div>
                  <div class="col-9 col-xl-12">
                    <div class="w-100 mt-3" style="height: 1px; background: rgba(0,0,0,.5);"></div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </section>
      </main>
      <!-- /Main Content -->

